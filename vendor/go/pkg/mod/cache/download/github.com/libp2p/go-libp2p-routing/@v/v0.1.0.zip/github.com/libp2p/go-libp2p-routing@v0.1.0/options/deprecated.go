// Deprecated: use github.com/libp2p/go-libp2p-core/routing instead.
package ropts

import core "github.com/libp2p/go-libp2p-core/routing"

// Deprecated: use github.com/libp2p/go-libp2p-core/routing/Option instead.
type Option = core.Option

// Deprecated: use github.com/libp2p/go-libp2p-core/routing/Options instead.
type Options = core.Options

// Deprecated: use github.com/libp2p/go-libp2p-core/routing.Expired instead.
var Expired = core.Expired

// Deprecated: use github.com/libp2p/go-libp2p-core/routing/Offline instead.
var Offline = core.Offline
