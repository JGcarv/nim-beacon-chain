// +build tools

package core

import (
	_ "github.com/smola/gocompat"
)
