package dht

import "log"

func init() {
	log.SetFlags(log.Flags() | log.Llongfile)
}
