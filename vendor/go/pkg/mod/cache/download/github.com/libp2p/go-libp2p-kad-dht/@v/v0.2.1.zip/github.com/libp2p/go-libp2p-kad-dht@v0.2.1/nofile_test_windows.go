package dht

func curFileLimit() uint64 {
	return 16 * 1024 * 1024
}
