# This script downloads latest test cases from specs

# TODO: change the link to when test cases are merged to specs repo

curl https://raw.githubusercontent.com/census-instrumentation/opencensus-specs/master/trace/http-out-test-cases.json -o http-out-test-cases.json